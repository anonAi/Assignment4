import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.mysql.jdbc.ResultSetRow;

public class GetData {
	public static Map<Integer,String> data = new HashMap<Integer,String>();
	public static ResultSet rs = null;
	
	public static int init() throws SQLException{
		 String sql;
		 String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		 Connection conn = null;
		 try{
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url);
			Statement stmt = conn.createStatement();
			
	        sql = "select * from 2014302580374_professor_info";
	        Statement statement = conn.createStatement();
	        
	        rs = statement.executeQuery(sql);
	        int i = 0;
	        while(rs.next()){
	        	data.put(i, rs.getString("name") + "\n" + rs.getString("tel") + "\n" + rs.getString("email") + "\n" + rs.getString("content"));
	        //	System.out.println(rs.getString("name") + "\n" + rs.getString("tel") + "\n" + rs.getString("email") + "\n" + rs.getString("content"));
	        	i++;
	        }
	        //System.out.println(rs.toString());
		 }catch (SQLException e) {
	            System.out.println("----- mysql error ----");
	            e.printStackTrace();
	     } catch (Exception e) {
	            e.printStackTrace();
	     } finally {
	            conn.close();
	     }

		return 0;
	}
}
