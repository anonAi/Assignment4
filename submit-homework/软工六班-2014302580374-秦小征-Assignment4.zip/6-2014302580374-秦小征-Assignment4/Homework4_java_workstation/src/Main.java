import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Main {

	public static JTextArea screen;
	
	public static JTextField input;
	
	private static JFrame frame;
	private static JButton btna;
	private static JScrollPane jscr;
	private static String sea = "";
	public static void main(String[] args) throws InterruptedException {

		frame = new JFrame("ATM- welcome");

		input = new JTextField();
		btna = new JButton("search");
		
		btna.setBackground(Color.green);
		btna.addActionListener(new ActionListener(){
	    	   public void actionPerformed(ActionEvent e){
	    		   try {
					btnaAction();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	    	   }
	       });
		frame.setLayout(new GridLayout(5,2,100,20));
	//	frame.add(label);
		screen = new JTextArea();
		jscr = new JScrollPane(screen);
		
		frame.add(jscr);
		frame.add(input);
		frame.add(btna);
		//screen.setText("cnaoehun\nhneaoh\nunhaeo\nnuhnte\nohunh\nenuhan\netuhneh\nou");
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500, 500);
		frame.setLocation(500, 200);
		//for(int i = 0; i < GetData.data.size(); i++){
		//}
	}
	public static Map<String, Integer> data = new HashMap<String, Integer>();
	public static Map<Integer, Integer> td = new HashMap<Integer, Integer>();
	public static void btnaAction() throws SQLException{
		if(GetData.init() == 0){
			;
		}else{
			System.out.println("error when GetData.init()");
		}
System.out.println("-------");
		for(int a = 0; a < GetData.data.size(); a++){
			String str = GetData.data.get(a);
			int index = 0;
			int i = 0;
			for(; ;){
				if(index + 1 < str.length()){
					index = str.indexOf(sea, index + 1);
				}else{
					index = -1;
				}
				//System.out.println(index);
				
				if(index < 0){
					//System.out.println("---index< 0");
					td.put(a, i);
					break;
				}
				i++;
			}
			
		}
//System.out.println("-------");
		for(int a = 0; a < GetData.data.size(); a++){
			data.put(GetData.data.get(a), td.get(a));
		}
//System.out.println("-------");
		// pai xu
		List<Map.Entry<String, Integer>> infoIds =
			    new ArrayList<Map.Entry<String, Integer>>(data.entrySet());

//System.out.println("-------");
			//排序
			Collections.sort(infoIds, new Comparator<Map.Entry<String, Integer>>() {   
			    public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {      
			        //return (o2.getValue() - o1.getValue()); 
			        return (o2.getValue()).compareTo(o1.getValue());
			    }
			}); 
			String out = "";
			for (int i = 0; i < infoIds.size(); i++) {
			    String id = infoIds.get(i).toString();
			    out +=id;
			}
			out += "\n请从初始位置(第一行)看. Thanks";
		screen.setText(out);
		
		
	}
}
